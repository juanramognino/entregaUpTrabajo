#!/bin/bash

#Esto mostra ayuda si se usa el -help
if [ "$1" = "-help" ]; then
	echo "Uso: $0 origen destino"
	echo "Ejemplo: $0 /var/log /backup_dir"
	echo ""
	echo "Este script crea/genera un backup comprimido en .tar.gz del direct origen"
	echo "y lo guarda en el destino, con fecha en formato pedido que es YYYY/MM/DD."
	echo ""
	exit 0
fi

#Scripts de backup basico - inicial ver

#Validar que se pasaron dos argumentos

if [ "$#" -ne 2 ]; then
	echo "Error: Se requieren dos argumntos: origen y destino."
	echo "Uso: $0 origen destino"
	exit 1
fi

origen="$1"
destino="$2"

echo "Origen: $origen"
echo "Destino: $destino"

#Validar que el origen existe seria esto
if [ ! -d "$origen" ]; then
	echo "Error: el directorio de origen '$origen' no existe"
	exit 2
fi

#Ahora validar que el destino existe
if [ ! -d "$destino" ]; then
	echo "Error: el directorio de destino '$destino' no existe"
	exit 3
fi

#Obt nombre base del origen (por ejemplo, "log" si es /var/log)
nombre_archivo=$(basename "$origen")

#Obt la fecha actual en formato YYYY/MMDD
fecha=$(date +%Y%m%d)


#Const el nombre final del backup
archivo_backup="${nombre_archivo}_bkp_${fecha}.tar.gz"

#Crear el archivo comprimido
tar -czf "$destino/$archivo_backup" "$origen"

#Conf final
echo "Backup generado: $destino/$archivo_backup"

